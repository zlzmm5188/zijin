<?php
/**
 * 项目详情API
 * GET /api/admin/project-detail.php?id=1
 * 获取单个项目详情
 */
require_once __DIR__ . '/../../config/bootstrap.php';

// 验证管理员权限
// TODO: 实现管理员Token验证

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id <= 0) {
    Response::error('项目ID无效');
}

$db = Database::getInstance();

try {
    // 查询项目详情
    $sql = "
        SELECT
            p.*,
            m.name as manager_name,
            m.avatar as manager_avatar,
            m.title as manager_title,
            m.introduction as manager_introduction
        FROM invest_projects p
        LEFT JOIN project_managers m ON p.manager_id = m.id
        WHERE p.id = :id
    ";

    $project = $db->fetchOne($sql, ['id' => $id]);

    if (!$project) {
        Response::error('项目不存在');
    }

    // 格式化数据
    $project['min_invest'] = (float)$project['min_invest'];
    $project['max_invest'] = (float)$project['max_invest'];
    $project['total_quota'] = (float)$project['total_quota'];
    $project['sold'] = (float)$project['sold'];
    $project['remain'] = (float)$project['remain'];
    $project['total_invested'] = (float)$project['total_invested'];

    $project['base_rate'] = (float)$project['base_rate'];
    $project['added_rate'] = (float)$project['added_rate'];
    $project['gift_rate'] = (float)$project['gift_rate'];
    $project['total_rate'] = (float)$project['total_rate'];

    $project['cycle_days'] = (int)$project['cycle_days'];
    $project['status'] = (int)$project['status'];
    $project['is_index'] = (int)$project['is_index'];
    $project['sort'] = (int)$project['sort'];
    $project['payment_type'] = (int)$project['payment_type'];
    $project['vip_min'] = (int)$project['vip_min'];
    $project['need_referral'] = (int)$project['need_referral'];
    $project['team_member_required'] = (int)$project['team_member_required'];
    $project['mcount'] = (int)$project['mcount'];
    $project['risk_level'] = (int)$project['risk_level'];
    $project['version'] = (int)$project['version'];
    $project['view_count'] = (int)$project['view_count'];
    $project['invest_count'] = (int)$project['invest_count'];

    $project['schedule'] = (float)$project['schedule'];

    Response::success($project, '获取成功');

} catch (Exception $e) {
    Response::error('查询失败: ' . $e->getMessage());
}
