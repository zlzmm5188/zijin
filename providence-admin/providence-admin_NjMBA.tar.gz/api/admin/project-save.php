<?php
/**
 * 项目添加/编辑API
 * POST /api/admin/project-save.php
 * 支持创建和更新项目
 */
require_once __DIR__ . '/../../config/bootstrap.php';

// 验证管理员权限
// TODO: 实现管理员Token验证

// 只接受POST请求
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    Response::error('请求方法错误');
}

$db = Database::getInstance();

try {
    // 获取表单数据
    $id = isset($_POST['id']) ? (int)$_POST['id'] : 0;
    $project_code = trim($_POST['project_code'] ?? '');
    $title = trim($_POST['title'] ?? '');
    $subtitle = trim($_POST['subtitle'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $category = trim($_POST['category'] ?? '');
    $currency = trim($_POST['currency'] ?? '');
    $cycle_days = (int)($_POST['cycle_days'] ?? 0);
    $base_rate = (float)($_POST['base_rate'] ?? 0);
    $added_rate = (float)($_POST['added_rate'] ?? 0);
    $gift_rate = (float)($_POST['gift_rate'] ?? 0);
    $min_invest = (float)($_POST['min_invest'] ?? 0);
    $max_invest = (float)($_POST['max_invest'] ?? 0);
    $total_quota = (float)($_POST['total_quota'] ?? 0);
    $manager_id = (int)($_POST['manager_id'] ?? 0);
    $status = (int)($_POST['status'] ?? 0);

    // 新增字段
    $is_index = (int)($_POST['is_index'] ?? 0);
    $sort = (int)($_POST['sort'] ?? 100);
    $payment_type = (int)($_POST['payment_type'] ?? 0);
    $vip_min = (int)($_POST['vip_min'] ?? 0);
    $need_referral = (int)($_POST['need_referral'] ?? 0);
    $team_member_required = (int)($_POST['team_member_required'] ?? 0);
    $mcount = (int)($_POST['mcount'] ?? 0);

    // 数据验证
    if (empty($title)) {
        Response::error('项目名称不能为空');
    }

    if (empty($category)) {
        Response::error('项目分类不能为空');
    }

    $validCategories = ['IPO', 'BOND', 'FUND', 'FIXED', 'INVEST'];
    if (!in_array($category, $validCategories)) {
        Response::error('项目分类无效');
    }

    if (empty($currency)) {
        Response::error('币种不能为空');
    }

    $validCurrencies = ['CNY', 'USDT'];
    if (!in_array($currency, $validCurrencies)) {
        Response::error('币种无效');
    }

    if ($cycle_days <= 0) {
        Response::error('投资周期必须大于0');
    }

    if ($base_rate < 0) {
        Response::error('基础利率不能为负数');
    }

    if ($min_invest <= 0) {
        Response::error('最小投资额必须大于0');
    }

    if ($max_invest < $min_invest) {
        Response::error('最大投资额不能小于最小投资额');
    }

    if ($total_quota <= 0) {
        Response::error('总额度必须大于0');
    }

    // 计算总利率（周期收益）
    $total_rate = $base_rate + $added_rate + $gift_rate;

    // 开始事务
    $db->beginTransaction();

    $data = [
        'title' => $title,
        'subtitle' => $subtitle,
        'description' => $description,
        'category' => $category,
        'currency' => $currency,
        'cycle_days' => $cycle_days,
        'base_rate' => $base_rate,
        'added_rate' => $added_rate,
        'gift_rate' => $gift_rate,
        'total_rate' => $total_rate,
        'min_invest' => $min_invest,
        'max_invest' => $max_invest,
        'total_quota' => $total_quota,
        'manager_id' => $manager_id,
        'status' => $status,
        'is_index' => $is_index,
        'sort' => $sort,
        'payment_type' => $payment_type,
        'vip_min' => $vip_min,
        'need_referral' => $need_referral,
        'team_member_required' => $team_member_required,
        'mcount' => $mcount,
        'updated_at' => date('Y-m-d H:i:s')
    ];

    if ($id > 0) {
        // 更新项目
        // 检查项目是否存在
        $existProject = $db->fetchOne(
            "SELECT id, version FROM invest_projects WHERE id = :id",
            ['id' => $id]
        );

        if (!$existProject) {
            Response::error('项目不存在');
        }

        // 更新版本号
        $data['version'] = (int)$existProject['version'] + 1;

        $success = $db->update('invest_projects', $data, ['id' => $id]);

        if (!$success) {
            throw new Exception('更新项目失败');
        }

        // 记录审计日志
        AuditLog::log(
            'project',
            '更新项目',
            'ADMIN',
            1,
            'invest_projects',
            $id,
            $existProject,
            $data
        );

        $db->commit();

        Response::success([
            'id' => $id,
            'version' => $data['version']
        ], '项目更新成功');

    } else {
        // 创建项目
        // 生成项目编号
        if (empty($project_code)) {
            $project_code = 'PRJ' . date('Ymd') . str_pad(rand(1, 999), 3, '0', STR_PAD_LEFT);
        }

        $data['project_code'] = $project_code;
        $data['version'] = 1;
        $data['schedule'] = 0;
        $data['view_count'] = 0;
        $data['invest_count'] = 0;
        $data['total_invested'] = 0;
        $data['sold'] = 0;
        $data['remain'] = $total_quota;
        $data['created_at'] = date('Y-m-d H:i:s');

        $newId = $db->insert('invest_projects', $data);

        if (!$newId) {
            throw new Exception('创建项目失败');
        }

        // 记录审计日志
        AuditLog::log(
            'project',
            '创建项目',
            'ADMIN',
            1,
            'invest_projects',
            $newId,
            null,
            $data
        );

        $db->commit();

        Response::success([
            'id' => $newId,
            'project_code' => $project_code,
            'version' => 1
        ], '项目创建成功');
    }

} catch (Exception $e) {
    $db->rollBack();
    Response::error('操作失败: ' . $e->getMessage());
}
