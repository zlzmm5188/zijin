<?php
/**
 * 提现审核通过API
 * POST /admin/withdraw-approve
 */
require_once __DIR__ . '/../../config/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    Response::error('请求方法错误');
}

// 验证管理员登录
$authUser = Auth::user();
if (!$authUser || !isset($authUser['is_admin']) || !$authUser['is_admin']) {
    Response::error('无权限访问', 403);
}

$input = json_decode(file_get_contents('php://input'), true);
$withdrawId = (int)($input['id'] ?? 0);
$actualAmount = (float)($input['actual_amount'] ?? 0);
$remark = trim($input['remark'] ?? '');

if ($withdrawId <= 0) {
    Response::error('提现记录ID无效');
}

if ($actualAmount <= 0) {
    Response::error('实际打款金额必须大于0');
}

$db = Database::getInstance();

try {
    $db->beginTransaction();

    // 获取提现记录
    $withdrawal = $db->fetchOne(
        "SELECT * FROM withdraw_records WHERE id = :id FOR UPDATE",
        ['id' => $withdrawId]
    );

    if (!$withdrawal) {
        throw new Exception('提现记录不存在');
    }

    if ($withdrawal['status'] != 0) {
        throw new Exception('该提现申请已经被处理');
    }

    // 更新提现记录状态
    $updateData = [
        'status' => 1, // 已通过
        'actual_amount' => $actualAmount,
        'reviewed_at' => date('Y-m-d H:i:s'),
        'remark' => $remark
    ];

    $success = $db->update(
        'withdraw_records',
        $updateData,
        'id = :id',
        ['id' => $withdrawId]
    );

    if (!$success) {
        throw new Exception('更新提现记录失败');
    }

    // 记录审计日志
    AuditLog::log(
        'withdrawal',
        '管理员审核通过提现申请',
        'ADMIN',
        $authUser['user_id'],
        'withdraw_records',
        $withdrawId,
        ['status' => 0],
        ['status' => 1, 'actual_amount' => $actualAmount, 'remark' => $remark]
    );

    $db->commit();

    Response::success([
        'withdrawal_id' => $withdrawId,
        'actual_amount' => $actualAmount
    ], '审核通过成功');

} catch (Exception $e) {
    $db->rollBack();
    error_log("提现审核通过API错误: " . $e->getMessage());
    Response::error('审核失败: ' . $e->getMessage());
}
