<?php
/**
 * 获取USDT充值信息（平台收款地址）
 * GET /pay/us/info
 */
require_once __DIR__ . '/../../config/bootstrap.php';

// 验证用户登录
$authUser = Auth::user();
if (!$authUser) {
    Response::error('未登录或登录已过期', 401);
}

// 返回平台USDT收款地址（应该从系统配置表读取）
Response::success([
    'usdt_address' => 'TYourPlatformUSDTAddressHere123456789',
    'network' => 'TRC20',
    'min_amount' => 10,
    'tips' => [
        '请确保转账网络为TRC20',
        '最低充值金额为10 USDT',
        '转账后请上传凭证',
        '充值将在审核通过后到账'
    ]
]);

