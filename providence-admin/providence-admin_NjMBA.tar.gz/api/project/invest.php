<?php
/**
 * 投资项目 (SRS + 缓存优化)
 * POST /fund/project/add
 */
require_once __DIR__ . '/../../config/bootstrap.php';

$authUser = Auth::user();
if (!$authUser) {
    Response::error('未登录或登录已过期', 401);
}

// 检查幂等性键
$idempotencyKey = $_SERVER['HTTP_IDEMPOTENCY_KEY'] ?? $_SERVER['HTTP_IDEMPOTENCY_KEY'] ?? null;
if ($idempotencyKey) {
    $cached = IdempotencyService::check($idempotencyKey, $authUser['user_id'], '/fund/project/add');
    if ($cached) {
        Response::success($cached['data'], '请勿重复提交');
    }
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    Response::error('请求方法错误');
}

$input = json_decode(file_get_contents('php://input'), true);
$projectId = (int)($input['project_id'] ?? 0);
$investAmount = (float)($input['amount'] ?? 0);
$currency = $input['currency'] ?? 'CNY';

if (!$projectId || $investAmount <= 0) {
    Response::error('参数错误');
}

$db = Database::getInstance();

// 获取项目（带锁，防止超卖）
$project = $db->fetchOne(
    "SELECT * FROM " . $db->getPrefix() . "invest_projects WHERE id = :id AND status = 1 FOR UPDATE", 
    ['id' => $projectId]
);

if (!$project) {
    Response::error('项目不存在或已下架');
}

// 币种隔离检查
CurrencyMiddleware::validate($currency, $project['currency'] ?? 'CNY');

// 检查剩余额度（从缓存读取）
if ($project['remain'] > 0 && $investAmount > $project['remain']) {
    Response::error('剩余额度不足');
}

// 获取用户
$user = $db->fetchOne("SELECT * FROM " . $db->getPrefix() . "users WHERE id = :id FOR UPDATE", 
    ['id' => $authUser['user_id']]);

// 检查余额
$balanceField = $currency == 'CNY' ? 'balance_cny' : 'balance_usdt';
$userBalance = $user[$balanceField] ?? $user['balance'];

if ($userBalance < $investAmount) {
    Response::error('余额不足');
}

// 获取VIP加息
$vipRule = $db->fetchOne(
    "SELECT extra_rate FROM " . $db->getPrefix() . "vip_interest_rules WHERE vip_level = :level",
    ['level' => $user['vip_level']]
);
$vipExtraRate = $vipRule['extra_rate'] ?? 0;

$cycleDays = $project['cycle_days'] ?? 30;
$baseRate = $project['base_rate'] ?? 0;
$addedRate = $project['added_rate'] ?? 0;
$giftRate = $project['gift_rate'] ?? 0;

// 计算最终收益率
$finalRate = $baseRate + $vipExtraRate + $addedRate + $giftRate;

// 使用EarningsService计算
$earnings = EarningsService::calculateEarnings($investAmount, $baseRate, $vipExtraRate + $addedRate + $giftRate, $cycleDays);

$orderNo = 'INV' . date('YmdHis') . rand(1000, 9999);
$startDate = date('Y-m-d');
$endDate = date('Y-m-d', strtotime("+{$cycleDays} days"));

$db->beginTransaction();

try {
    // 创建订单
    $orderId = $db->insert('invest_orders', [
        'order_no' => $orderNo,
        'user_id' => $user['id'],
        'project_id' => $projectId,
        'currency' => $currency,
        'amount' => $investAmount,
        'vip_level' => $user['vip_level'],
        'base_rate' => $baseRate,
        'vip_extra_rate' => $vipExtraRate,
        'added_rate' => $addedRate,
        'gift_rate' => $giftRate,
        'final_rate' => $finalRate,
        'cycle_days' => $cycleDays,
        'expected_profit' => $earnings['profit'],
        'status' => 'RUNNING',
        'start_at' => $startDate,
        'end_at' => $endDate
    ]);
    
    // 扣除余额
    $db->update('users', [$balanceField => $userBalance - $investAmount], 'id = :id', ['id' => $user['id']]);
    
    // 更新项目统计
    $db->query(
        "UPDATE " . $db->getPrefix() . "invest_projects 
         SET invest_count = invest_count + 1, total_invested = total_invested + :amount 
         WHERE id = :id",
        ['amount' => $investAmount, 'id' => $projectId]
    );
    
    // 【更新项目缓存】⭐
    ProjectCacheService::updateCache($projectId);
    
    // VIP升级
    VipService::checkAndUpgrade($user['id']);
    
    // 审计日志
    AuditLog::log('project', '投资项目', 'USER', $user['id'], 'invest_order', $orderId);
    
    $db->commit();
    
    $result = [
        'order_id' => $orderId,
        'order_no' => $orderNo,
        'invest_amount' => $investAmount,
        'currency' => $currency,
        'profit' => $earnings['profit'],
        'total' => $earnings['total'],
        'daily_profit' => $earnings['daily_profit'],
        'end_date' => $endDate
    ];
    
    // 保存幂等性响应
    if ($idempotencyKey) {
        IdempotencyService::save($idempotencyKey, $authUser['user_id'], '/fund/project/add', $result);
    }
    
    Response::success($result, '投资成功');
    
} catch (Exception $e) {
    $db->rollBack();
    Response::error('投资失败: ' . $e->getMessage());
}
