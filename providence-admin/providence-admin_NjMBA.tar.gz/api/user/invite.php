<?php
/**
 * 邀请信息 - 修复版（只查询uid）
 * GET /user/user/invite
 */
require_once __DIR__ . './../../config/bootstrap.php';

$authUser = Auth::user();
if (!$authUser) {
    Response::error('未登录或登录已过期', 401);
}

$db = Database::getInstance();

// 修复：只查询uid字段（表中没有invite_code字段）
$user = $db->fetchOne("SELECT uid FROM " . $db->getPrefix() . "users WHERE id = :id", ['id' => $authUser['user_id']]);

// 统计邀请数据
$directCount = $db->count('users', 'parent_id = :id', ['id' => $authUser['user_id']]);

// 使用UID作为主要邀请标识
$uid = $user['uid'] ?? null;

Response::success([
    'uid' => $uid,                                    // 用户UID（8位数字）
    'invite' => $uid,                                 // 主要邀请ID（就是uid）
    'invite_url' => $uid ? 'https://' . $uid . '.' . $_SERVER['HTTP_HOST'] : null,
    'direct_count' => $directCount,
    'total_reward' => 0 // TODO: 统计总奖励
]);
