<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once __DIR__ . '/../bootstrap.php';

try {
    // 验证用户登录
    $user = Auth::user();
    if (!isset($user['id'])) {
        Response::error('未登录');
    }
    
    $user_id = $user['id'];
    
    // 获取POST数据
    $input = json_decode(file_get_contents('php://input'), true);
    $amount = floatval($input['amount'] ?? 0);
    $pay_password = $input['pay_password'] ?? '';
    
    // 验证金额
    if ($amount < 100) {
        Response::error('转出金额不能低于100元');
    }
    
    // 验证支付密码
    if (empty($pay_password)) {
        Response::error('请输入支付密码');
    }
    
    $stmt = $pdo->prepare("SELECT pay_password FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $userInfo = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!password_verify($pay_password, $userInfo['pay_password'])) {
        Response::error('支付密码错误');
    }
    
    // 开启事务
    $pdo->beginTransaction();
    
    try {
        // 检查日利宝余额
        $stmt = $pdo->prepare("SELECT ribao_balance FROM users WHERE id = ? FOR UPDATE");
        $stmt->execute([$user_id]);
        $ribao_balance = floatval($stmt->fetchColumn());
        
        if ($ribao_balance < $amount) {
            throw new Exception('日利宝余额不足');
        }
        
        // 扣除日利宝余额
        $stmt = $pdo->prepare("UPDATE users SET ribao_balance = ribao_balance - ? WHERE id = ?");
        $stmt->execute([$amount, $user_id]);
        
        // 增加余额
        $stmt = $pdo->prepare("UPDATE users SET balance = balance + ? WHERE id = ?");
        $stmt->execute([$amount, $user_id]);
        
        // 记录日志
        $stmt = $pdo->prepare("
            INSERT INTO ribao_logs (user_id, type, amount, created_at) 
            VALUES (?, 'transfer_out', ?, NOW())
        ");
        $stmt->execute([$user_id, $amount]);
        
        $pdo->commit();
        
        Response::success('转出成功', [
            'amount' => $amount,
            'time' => date('Y-m-d H:i:s')
        ]);
        
    } catch (Exception $e) {
        $pdo->rollBack();
        Response::error($e->getMessage());
    }
    
} catch (Exception $e) {
    Response::error('系统错误: ' . $e->getMessage());
}
