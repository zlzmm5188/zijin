<?php
/**
 * 领取团队奖励
 * POST /user/team/claim_reward
 */
require_once __DIR__ . '/../../config/bootstrap.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    Response::error('请求方法错误');
}

$authUser = Auth::user();
if (!$authUser) {
    Response::error('未登录或登录已过期', 401);
}

// 简化实现：暂无可领取奖励
Response::error('暂无可领取的团队奖励');
