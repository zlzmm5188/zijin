<?php
/**
 * 获取团队奖励状态
 * GET /user/team/rewards_status
 */
require_once __DIR__ . '/../../config/bootstrap.php';

$authUser = Auth::user();
if (!$authUser) {
    Response::error('未登录或登录已过期', 401);
}

// 简化实现：返回可领取奖励为0
Response::success([
    'available_rewards' => 0,
    'total_rewards' => 0,
    'claimed_rewards' => 0
]);
