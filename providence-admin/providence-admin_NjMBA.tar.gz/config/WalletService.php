<?php
/**
 * 钱包服务类
 * 处理多币种钱包操作
 */
class WalletService {
    /**
     * 添加钱包流水
     */
    public static function addLog($userId, $type, $amount, $currency, $refId = null, $remark = '') {
        $db = Database::getInstance();
        
        // 获取当前余额
        $user = $db->fetchOne("SELECT balance FROM " . $db->getPrefix() . "users WHERE id = :id", 
            ['id' => $userId]);
        
        $balanceBefore = $user['balance'] ?? 0;
        $balanceAfter = $balanceBefore + $amount;
        
        return $db->insert('wallet_logs', [
            'user_id' => $userId,
            'type' => $type,
            'amount' => $amount,
            'balance_before' => $balanceBefore,
            'balance_after' => $balanceAfter,
            'currency' => $currency,
            'ref_type' => 'order',
            'ref_id' => $refId,
            'remark' => $remark
        ]);
    }
    
    /**
     * 检查余额是否足够
     */
    public static function hasEnoughBalance($userId, $amount, $currency = 'CNY') {
        $db = Database::getInstance();
        $user = $db->fetchOne("SELECT balance FROM " . $db->getPrefix() . "users WHERE id = :id", 
            ['id' => $userId]);
        
        return ($user['balance'] ?? 0) >= $amount;
    }
}
