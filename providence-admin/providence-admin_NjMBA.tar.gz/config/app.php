<?php
/**
 * 应用配置文件
 */
return [
    'app_name' => 'PROVIDENCE',
    'app_url' => 'http://72.60.234.87',
    'admin_url' => 'http://72.60.234.87/providence-admin',
    'api_url' => 'http://72.60.234.87/providence-admin/api',
    
    // 安全配置
    'jwt_secret' => 'Providence_JWT_Secret_Key_2024_Secure_Random_String',
    'password_salt' => 'Providence_Password_Salt_2024',
    
    // 文件上传
    'upload_path' => __DIR__ . '/../uploads/',
    'upload_max_size' => 5 * 1024 * 1024, // 5MB
    'upload_allowed_ext' => ['jpg', 'jpeg', 'png', 'gif', 'pdf'],
    
    // 分页配置
    'page_size' => 20,
    
    // 时区
    'timezone' => 'Asia/Shanghai',
];
