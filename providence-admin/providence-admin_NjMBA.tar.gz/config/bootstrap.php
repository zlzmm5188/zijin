<?php
/**
 * 框架引导文件 (SRS v1.0 + 企业级)
 */

error_reporting(E_ALL);
ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/../logs/error.log');

date_default_timezone_set('Asia/Shanghai');

// 核心类
require_once __DIR__ . '/constants.php';
require_once __DIR__ . '/Database.php';
require_once __DIR__ . '/Response.php';
require_once __DIR__ . '/Auth.php';
require_once __DIR__ . '/Upload.php';
require_once __DIR__ . '/AuditLog.php';
require_once __DIR__ . '/SignValidator.php';
require_once __DIR__ . '/Validator.php';  // SRS规范：数据验证器

// 业务服务类（SRS规范）
require_once __DIR__ . '/VipService.php';
require_once __DIR__ . '/EarningsService.php';
require_once __DIR__ . '/ReferralService.php';
require_once __DIR__ . '/WalletService.php';
require_once __DIR__ . '/OrderService.php';
require_once __DIR__ . '/CurrencyMiddleware.php';
require_once __DIR__ . '/IdempotencyService.php';
require_once __DIR__ . '/ProjectCacheService.php';  // 项目缓存服务

// CORS - 所有请求都需要CORS头
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization, token, sign, timestamp, X-Signature, X-Timestamp, X-Nonce, Idempotency-Key');
header('Access-Control-Allow-Credentials: true');

// OPTIONS预检请求直接返回
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit(0);
}
