/**
 * 全面检查所有API调用错误
 * 用于在浏览器控制台运行，检查所有API调用
 */

(function() {
    console.log('🔍 开始检查所有API调用...\n');

    const errors = [];
    const warnings = [];

    // 拦截fetch请求
    const originalFetch = window.fetch;
    window.fetch = function(...args) {
        const url = args[0];
        const options = args[1] || {};

        // 只检查API请求
        if (typeof url === 'string' && url.includes('api.frevix.top')) {
            console.log(`📡 [API请求] ${options.method || 'GET'} ${url}`);

            return originalFetch.apply(this, args)
                .then(response => {
                    // 检查响应
                    const contentType = response.headers.get('content-type') || '';
                    const isJSON = contentType.includes('application/json');

                    if (!isJSON && response.status !== 200) {
                        errors.push({
                            url,
                            method: options.method || 'GET',
                            status: response.status,
                            issue: '返回非JSON格式或错误状态码'
                        });
                        console.error(`❌ [API错误] ${url} - HTTP ${response.status}, 非JSON响应`);
                    }

                    return response;
                })
                .catch(error => {
                    errors.push({
                        url,
                        method: options.method || 'GET',
                        error: error.message
                    });
                    console.error(`❌ [API错误] ${url} - ${error.message}`);
                    throw error;
                });
        }

        return originalFetch.apply(this, args);
    };

    // 检查所有已知的API端点
    const knownAPIs = [
        '/user/user/index',
        '/user/project/list',
        '/user/order/list',
        '/user/ribao/head',
        '/user/ribao/list',
        '/user/ribao/in',
        '/user/ribao/out',
        '/user/team/reward-rules',
        '/user/team/my-rewards',
        '/user/team/claim-reward',
        '/user/vip/progress',
        '/user/checkin/status',
        '/user/checkin/do',
        '/user/points/goods',
        '/user/points/exchange',
        '/user/level/list',
        '/user/user/invite',
        '/fund/project/all',
        '/fund/project/detail',
        '/fund/project/add',
        '/login/login/account',
        '/pay/bank/list',
        '/pay/pay/recharge',
        '/pay/pay/withdraw'
    ];

    console.log('📋 已知API端点:', knownAPIs.length, '个');
    console.log('\n等待页面加载完成...\n');

    // 5秒后输出报告
    setTimeout(() => {
        console.log('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        console.log('📊 API检查报告');
        console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');

        if (errors.length > 0) {
            console.error(`❌ 发现 ${errors.length} 个API错误:\n`);
            errors.forEach((err, i) => {
                console.error(`${i + 1}. ${err.method || 'GET'} ${err.url}`);
                console.error(`   状态: ${err.status || 'N/A'}`);
                console.error(`   问题: ${err.issue || err.error}\n`);
            });
        } else {
            console.log('✅ 未发现API错误');
        }

        console.log('\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    }, 5000);

    // 导出错误列表供外部使用
    window.__apiErrors = errors;
})();
