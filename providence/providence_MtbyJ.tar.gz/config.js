// ===================================
// Providence 前台通用 API 配置
// 重建时间：2025-11-12
// ===================================

const API_CONFIG = {
  baseURL: 'https://api.frevix.top',
  adminURL: 'https://api.frevix.top/octohoutai.php',
  tokenKey: 'providence_token',
  timeout: 15000,
  debug: false
};

class HttpClient {
  constructor(config) {
    this.baseURL = config.baseURL;
    this.timeout = config.timeout;
    this.debug = config.debug;
  }

  getToken() {
    try {
      return localStorage.getItem(API_CONFIG.tokenKey) || '';
    } catch (err) {
      console.warn('getToken fail', err);
      return '';
    }
  }

  buildHeaders(extra = {}) {
    const headers = {
      'Content-Type': 'application/json',
      ...extra
    };
    const token = this.getToken();
    if (token) headers['Authorization'] = token;
    return headers;
  }

  async request(method, url, body = null, extraHeaders = {}) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), this.timeout);
    const options = {
      method,
      headers: this.buildHeaders(extraHeaders),
      signal: controller.signal
    };
    if (body) options.body = JSON.stringify(body);

    let response;
    let result;
    try {
      if (this.debug) {
        console.log('[HTTP] request', method, url, body);
      }
      response = await fetch(this.baseURL + url, options);
      const text = await response.text();
      try {
        result = text ? JSON.parse(text) : {};
      } catch (err) {
        if (this.debug) {
          console.error('[HTTP] JSON parse error', err, text);
        }
        throw new Error('响应解析失败');
      }
      return {
        status: response.status,
        ok: response.ok,
        data: result
      };
    } finally {
      clearTimeout(timeoutId);
    }
  }

  async get(url, params = {}, extraHeaders = {}) {
    const query = new URLSearchParams(params).toString();
    const fullUrl = query ? `${url}?${query}` : url;
    return this.request('GET', fullUrl, null, extraHeaders);
  }

  async post(url, data = {}, extraHeaders = {}) {
    return this.request('POST', url, data, extraHeaders);
  }
}

const http = new HttpClient(API_CONFIG);

const ApiService = {
  auth: {
    saveToken(token) {
      try {
        localStorage.setItem(API_CONFIG.tokenKey, token || '');
      } catch (err) {
        console.warn('saveToken fail', err);
      }
    },
    clearToken() {
      try {
        localStorage.removeItem(API_CONFIG.tokenKey);
      } catch (err) {
        console.warn('clearToken fail', err);
      }
    },
    ensureLogin() {
      const token = localStorage.getItem(API_CONFIG.tokenKey);
      if (!token) {
        window.location.href = 'login.html';
        return false;
      }
      return true;
    }
  },

  ribao: {
    async getInfo() {
      const res = await http.get('/user/ribao-info');
      return res.data || {};
    },
    async transferIn(payload) {
      const res = await http.post('/user/ribao-transfer-in', payload);
      return res.data || {};
    },
    async transferOut(payload) {
      const res = await http.post('/user/ribao-transfer-out', payload);
      return res.data || {};
    },
    async getRecords(params = {}) {
      const res = await http.get('/user/ribao-records', params);
      return res.data || {};
    }
  },

  points: {
    async getBalance() {
      const res = await http.get('/user/points-balance');
      return res.data || {};
    },
    async exchange(payload) {
      const res = await http.post('/user/points-exchange', payload);
      return res.data || {};
    },
    async getLogs(params = {}) {
      const res = await http.get('/points/logs', params);
      return res.data || {};
    }
  },

  finance: {
    async getUserBalance() {
      const res = await http.get('/user/balance');
      return res.data || {};
    },
    async recharge(payload) {
      const res = await http.post('/pay/recharge', payload);
      return res.data || {};
    },
    async withdraw(payload) {
      const res = await http.post('/pay/withdraw', payload);
      return res.data || {};
    },
    async getBankList() {
      const res = await http.get('/pay/bank-list');
      return res.data || {};
    },
    async getUsdtInfo() {
      const res = await http.get('/pay/usdt-info');
      return res.data || {};
    }
  }
};

window.ApiService = ApiService;
window.httpClient = http;
