/**
 * Providence 手势控制
 * 实现右滑返回功能
 */

(function() {
    console.log('📱 手势控制已加载');

    let touchStartX = 0;
    let touchStartY = 0;
    let touchStartTime = 0;

    // 监听触摸开始
    document.addEventListener('touchstart', function(e) {
        touchStartX = e.touches[0].clientX;
        touchStartY = e.touches[0].clientY;
        touchStartTime = Date.now();
    }, { passive: true });

    // 监听触摸结束
    document.addEventListener('touchend', function(e) {
        const touchEndX = e.changedTouches[0].clientX;
        const touchEndY = e.changedTouches[0].clientY;
        const touchEndTime = Date.now();

        const deltaX = touchEndX - touchStartX;
        const deltaY = touchEndY - touchStartY;
        const deltaTime = touchEndTime - touchStartTime;

        // 判断是否是右滑手势
        const isSwipeRight = deltaX > 100; // 滑动距离大于100px
        const isStartFromEdge = touchStartX < 50; // 从屏幕左侧边缘开始
        const isHorizontal = Math.abs(deltaX) > Math.abs(deltaY) * 2; // 水平滑动为主
        const isFast = deltaTime < 300; // 滑动时间小于300ms

        if (isSwipeRight && isStartFromEdge && isHorizontal && isFast) {
            console.log('👉 检测到右滑返回手势');

            // 检查是否可以返回
            if (window.history.length > 1) {
                window.history.back();
            } else {
                // 如果没有历史记录,返回首页
                window.location.href = 'index.html';
            }
        }
    }, { passive: true });

    // 防止iOS默认的返回手势冲突
    document.addEventListener('touchmove', function(e) {
        const touchX = e.touches[0].clientX;
        if (touchStartX < 50 && touchX - touchStartX > 30) {
            // 允许自定义手势
            console.log('🔒 阻止默认返回手势');
        }
    }, { passive: true });

})();

console.log('✅ 手势控制初始化完成');
