<?php
/**
 * 实名认证人脸比对接口 - InsightFace版本
 * 第二道防线：自动比对身份证照片和自拍照
 */

header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, token');
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit();
}

// 数据库配置
define('DB_HOST', 'localhost');
define('DB_NAME', 'providence');
define('DB_USER', 'providence');
define('DB_PASS', 'Providence@2024');

// Python脚本路径
define('PYTHON_SCRIPT', '/www/wwwroot/providence-ocr/face_compare_insightface.py');

/**
 * 返回JSON响应
 */
function jsonResponse($code, $message, $data = []) {
    echo json_encode([
        'code' => $code,
        'message' => $message,
        'data' => $data
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

/**
 * 获取数据库连接
 */
function getDB() {
    try {
        $pdo = new PDO(
            "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
            DB_USER,
            DB_PASS,
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
            ]
        );
        return $pdo;
    } catch (PDOException $e) {
        jsonResponse(-1, '数据库连接失败');
    }
}

/**
 * 验证用户token
 */
function verifyUser() {
    $token = $_POST['token'] ?? $_SERVER['HTTP_TOKEN'] ?? '';
    
    if (empty($token)) {
        jsonResponse(-1, '请先登录', ['need_login' => true]);
    }
    
    $db = getDB();
    $stmt = $db->prepare("SELECT id, username FROM users WHERE token = ? AND status = 1");
    $stmt->execute([$token]);
    $user = $stmt->fetch();
    
    if (!$user) {
        jsonResponse(-1, '登录已过期，请重新登录', ['need_login' => true]);
    }
    
    return $user;
}

/**
 * 调用Python脚本进行人脸比对
 */
function compareFacesWithInsightFace($idCardPhotoPath, $selfiePhotoPath) {
    $command = sprintf(
        'python3 %s %s %s 2>&1',
        escapeshellarg(PYTHON_SCRIPT),
        escapeshellarg($idCardPhotoPath),
        escapeshellarg($selfiePhotoPath)
    );
    
    $output = shell_exec($command);
    $result = json_decode($output, true);
    
    if (!$result || !isset($result['success'])) {
        return [
            'success' => false,
            'message' => '人脸识别服务异常'
        ];
    }
    
    return $result;
}

// ========== 主逻辑 ==========

// 只接受POST请求
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonResponse(-1, '请求方法错误');
}

// 验证用户登录
$user = verifyUser();
$userId = $user['id'];

// 检查是否已提交过认证
$db = getDB();
$stmt = $db->prepare("SELECT * FROM user_kyc WHERE user_id = ? AND status IN (0, 2) ORDER BY id DESC LIMIT 1");
$stmt->execute([$userId]);
$existingKyc = $stmt->fetch();

if ($existingKyc) {
    if ($existingKyc['status'] == 2) {
        jsonResponse(-1, '您已完成实名认证');
    } else {
        jsonResponse(-1, '您的认证正在审核中，请勿重复提交');
    }
}

// 检查上传文件
if (!isset($_FILES['id_card']) || !isset($_FILES['selfie'])) {
    jsonResponse(-1, '请上传身份证和自拍照');
}

$idCardFile = $_FILES['id_card'];
$selfieFile = $_FILES['selfie'];

// 验证文件类型
$allowedTypes = ['image/jpeg', 'image/jpg', 'image/png'];
if (!in_array($idCardFile['type'], $allowedTypes) || !in_array($selfieFile['type'], $allowedTypes)) {
    jsonResponse(-1, '只支持JPG和PNG格式');
}

// 验证文件大小（5MB）
if ($idCardFile['size'] > 5 * 1024 * 1024 || $selfieFile['size'] > 5 * 1024 * 1024) {
    jsonResponse(-1, '照片大小不能超过5MB');
}

// 创建临时目录
$tempDir = '/www/wwwroot/providence/uploads/kyc/temp/' . $userId . '_' . time();
if (!is_dir($tempDir)) {
    mkdir($tempDir, 0755, true);
}

// 保存到临时目录
$tempIdCard = $tempDir . '/id_card.jpg';
$tempSelfie = $tempDir . '/selfie.jpg';

if (!move_uploaded_file($idCardFile['tmp_name'], $tempIdCard)) {
    jsonResponse(-1, '身份证照片保存失败');
}

if (!move_uploaded_file($selfieFile['tmp_name'], $tempSelfie)) {
    @unlink($tempIdCard);
    jsonResponse(-1, '自拍照保存失败');
}

// 调用Python脚本进行人脸比对
$result = compareFacesWithInsightFace($tempIdCard, $tempSelfie);

// 检查识别结果
if (!$result['success']) {
    // 删除临时文件
    @unlink($tempIdCard);
    @unlink($tempSelfie);
    @rmdir($tempDir);
    jsonResponse(-1, $result['message'] ?? '人脸识别失败');
}

// 获取相似度
$similarity = floatval($result['similarity'] ?? 0);
$isMatch = $similarity >= 80; // 阈值：80%

if (!$isMatch) {
    // 不匹配 - 删除临时文件
    @unlink($tempIdCard);
    @unlink($tempSelfie);
    @rmdir($tempDir);
    
    // 记录失败尝试
    $stmt = $db->prepare("
        INSERT INTO kyc_verify_log (user_id, similarity, result, ip, created_at)
        VALUES (?, ?, 'failed', ?, NOW())
    ");
    $stmt->execute([$userId, $similarity, $_SERVER['REMOTE_ADDR'] ?? '']);
    
    jsonResponse(-1, '人脸不匹配，请本人对准识别重新拍照', [
        'similarity' => $similarity,
        'threshold' => 80
    ]);
}

// 匹配成功 - 移动到正式目录
$finalDir = '/www/wwwroot/providence/uploads/kyc/' . $userId;
if (!is_dir($finalDir)) {
    mkdir($finalDir, 0755, true);
}

$timestamp = time();
$finalIdCard = $finalDir . '/id_card_' . $timestamp . '.jpg';
$finalSelfie = $finalDir . '/selfie_' . $timestamp . '.jpg';

if (!rename($tempIdCard, $finalIdCard) || !rename($tempSelfie, $finalSelfie)) {
    jsonResponse(-1, '文件保存失败');
}

// 删除临时目录
@rmdir($tempDir);

// 转换为相对路径
$idCardPath = str_replace('/www/wwwroot/providence', '', $finalIdCard);
$selfiePath = str_replace('/www/wwwroot/providence', '', $finalSelfie);

// 获取real_name和id_card（从OCR或用户输入）
$realName = $_POST['real_name'] ?? '';
$idCard = $_POST['id_card'] ?? '';

// 保存到数据库
$stmt = $db->prepare("
    INSERT INTO user_kyc (
        user_id, real_name, id_card, id_card_front, hand_held_photo,
        face_similarity, face_check_result, face_check_time, 
        submit_time, status, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, 'auto_passed', NOW(), NOW(), 0, NOW())
");

$stmt->execute([
    $userId,
    $realName,
    $idCard,
    $idCardPath,
    $selfiePath,
    $similarity
]);

$kycId = $db->lastInsertId();

// 记录成功日志
$stmt = $db->prepare("
    INSERT INTO kyc_verify_log (user_id, kyc_id, similarity, result, ip, created_at)
    VALUES (?, ?, ?, 'success', ?, NOW())
");
$stmt->execute([$userId, $kycId, $similarity, $_SERVER['REMOTE_ADDR'] ?? '']);

// 返回成功
jsonResponse(1, '验证成功，您的实名认证已提交', [
    'kyc_id' => $kycId,
    'similarity' => $similarity,
    'status' => 'pending'
]);
