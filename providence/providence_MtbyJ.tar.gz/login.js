// 登录页面 - 统一使用config.js的API封装
// 确保在HTML中已加载config.js: <script src="config.js"></script>
const AREA_CODE = '86';
const SYSTEM_FLAG = 1;

// 等待API对象加载
function waitForAPI() {
    return new Promise((resolve) => {
        if (window.API && window.API_CONFIG) {
            resolve();
        } else {
            const check = setInterval(() => {
                if (window.API && window.API_CONFIG) {
                    clearInterval(check);
                    resolve();
                }
            }, 50);
            setTimeout(() => {
                clearInterval(check);
                resolve();
            }, 3000);
        }
    });
}

document.addEventListener('DOMContentLoaded', function () {
    initPage();
    loadSavedCredentials(); // 加载保存的账号密码
});

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
// 新增：记住密码功能
// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

function loadSavedCredentials() {
    const savedUsername = localStorage.getItem('saved_username');
    const savedPassword = localStorage.getItem('saved_password');
    const rememberMe = localStorage.getItem('remember_me') === 'true';

    if (savedUsername) {
        const usernameEl = document.getElementById('loginUsername');
        if (usernameEl) usernameEl.value = savedUsername;
    }

    if (rememberMe && savedPassword) {
        const passwordEl = document.getElementById('loginPassword');
        if (passwordEl) passwordEl.value = savedPassword;
        console.log('[登录] 已自动填充保存的账号密码');
    }
}

function saveCredentials(username, password, remember) {
    if (remember) {
        localStorage.setItem('saved_username', username);
        localStorage.setItem('saved_password', password);
        localStorage.setItem('remember_me', 'true');
        console.log('[登录] 已保存账号密码');
    } else {
        localStorage.removeItem('saved_password');
        localStorage.setItem('remember_me', 'false');
        console.log('[登录] 已清除保存的密码');
    }
}

// ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
document.addEventListener('DOMContentLoaded', function () {
    initPage();
});

function initPage() {
    // 标签切换
    document.querySelectorAll('.form-tab').forEach(tab => {
        tab.addEventListener('click', function () {
            const tabType = this.dataset.tab;
            switchTab(tabType);
        });
    });

    // 回车登录
    document.addEventListener('keypress', function (e) {
        if (e.key === 'Enter') {
            handleLogin();
        }
    });
}

function switchTab(tabType) {
    document.querySelectorAll('.form-tab').forEach(t => t.classList.remove('active'));
    const tabBtn = document.querySelector(`[data-tab="${tabType}"]`);
    if (tabBtn) tabBtn.classList.add('active');

    const accountEl = document.getElementById('accountForm');
    const smsEl = document.getElementById('smsForm');
    if (accountEl) accountEl.classList.add('hidden');
    if (smsEl) smsEl.classList.add('hidden');

    if (tabType === 'account') {
        if (accountEl) accountEl.classList.remove('hidden');
    } else {
        if (smsEl) smsEl.classList.remove('hidden');
    }
}

// 账号登录
async function handleLogin() {
    if (window.__loginLoading) return;
    window.__loginLoading = true;
    const btn = document.getElementById('btnLogin');
    if (btn) { btn.classList.add('btn-loading'); btn.disabled = true; }

    const usernameEl = document.getElementById('loginUsername');
    const passwordEl = document.getElementById('loginPassword');

    // 清除HTML5验证错误
    if (usernameEl) {
        usernameEl.setCustomValidity('');
        usernameEl.reportValidity();
    }
    if (passwordEl) {
        passwordEl.setCustomValidity('');
        passwordEl.reportValidity();
    }

    const username = usernameEl ? usernameEl.value.trim() : '';
    const password = passwordEl ? passwordEl.value.trim() : '';

    if (!username) {
        showToast('请输入账号');
        if (btn) { btn.classList.remove('btn-loading'); btn.disabled = false; }
        window.__loginLoading = false;
        return;
    }

    if (!password) {
        showToast('请输入密码');
        if (btn) { btn.classList.remove('btn-loading'); btn.disabled = false; }
        window.__loginLoading = false;
        return;
    }

    try {
        await waitForAPI();

        // ⚠️ 临时禁用API封装，直接使用fetch（因为封装有bug）
        // if (window.API && window.API.user && window.API.user.login) {
        //     const result = await window.API.user.login(username, password);
        //     if (result.success && result.data) {
        //         try {
        //             localStorage.setItem('providence_token', result.data.access_token || result.data.token);
        //             localStorage.setItem('providence_user_id', result.data.user_id || result.data.id);
        //             localStorage.setItem('providence_user_name', username);
        //         } catch(e){}
        //         window.location.href = 'index.html';
        //         return;
        //     } else {
        //         showToast('提示', result.msg || '账号或密码错误');
        //         return;
        //     }
        // }

        // 直接使用fetch（稳定可靠）
        const API_BASE = window.API_CONFIG?.baseURL || 'https://api.frevix.top';
        const response = await fetch(API_BASE + '/api/login.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });

        let text = await response.text();
        let data;
        try {
            data = JSON.parse(text);
        } catch (e) {
            console.error('登录返回(非JSON):', text.substring(0, 200));
            // 检查是否是HTML错误页面
            if (text.trim().startsWith('<!DOCTYPE') || text.trim().startsWith('<html')) {
                showToast('服务器返回错误页面，请检查网络或联系管理员');
            } else {
                showToast('服务器响应格式错误，请稍后再试');
            }
            return;
        }

        // 统一格式：code: 1 表示成功
        if (data.code === 1 && data.data) {
            try {
                localStorage.setItem('providence_token', data.data.access_token || data.data.token);
                localStorage.setItem('providence_user_id', data.data.user_id || data.data.user?.id || data.data.id);
                localStorage.setItem('providence_user_name', username);
            } catch (e) { }
            // 保存账号密码
            saveCredentials(username, password, false);
            showToast('登录成功');
            setTimeout(() => {
                window.location.href = 'index.html';
            }, 500);
        } else {
            showToast(data.message || data.msg || '账号或密码错误');
        }
    } catch (error) {
        console.error('登录错误:', error);
        showToast('网络错误，请重试');
    } finally {
        if (btn) { btn.classList.remove('btn-loading'); btn.disabled = false; }
        window.__loginLoading = false;
    }
}

// 短信登录
async function handleSmsLogin() {
    const mobile = document.getElementById('smsMobile').value;
    const code = document.getElementById('smsCode').value;

    if (!mobile) {
        showToast('请输入手机号');
        return;
    }

    if (!code) {
        showToast('请输入验证码');
        return;
    }

    try {
        await waitForAPI();

        // 使用统一API封装
        const API_BASE = window.API_CONFIG?.baseURL || 'https://api.frevix.top';
        const response = await fetch(API_BASE + '/login/login/sms', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                area: parseInt(AREA_CODE, 10),
                mobile: AREA_CODE + mobile,
                system: SYSTEM_FLAG,
                sms: code
            })
        });

        const data = await response.json();
        console.log('短信登录返回:', data);

        if (data.code === 1 && data.data) {
            try { localStorage.setItem('providence_token', data.data.access_token || data.data.token); } catch (e) { }
            // 短信登录不保存密码
            showToast('登录成功');
            setTimeout(() => { window.location.href = 'index.html'; }, 1000);
        } else {
            showToast(data.msg || '登录失败');
        }
    } catch (error) {
        console.error('登录错误:', error);
        showToast('网络错误，请重试');
    }
}

// 发送短信验证码
let smsCountdown = 0;
async function sendSms() {
    const mobile = document.getElementById('smsMobile').value;

    if (!mobile) {
        showToast('请输入手机号');
        return;
    }

    if (!/^1[3-9]\d{9}$/.test(mobile)) {
        showToast('请输入正确的手机号');
        return;
    }

    if (smsCountdown > 0) {
        showToast(`请等待${smsCountdown}秒后再试`);
        return;
    }

    try {
        await waitForAPI();
        const API_BASE = window.API_CONFIG?.baseURL || 'https://api.frevix.top';
        const response = await fetch(API_BASE + '/login/sms/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                area: parseInt(AREA_CODE, 10),
                mobile: AREA_CODE + mobile,
                mobile2: mobile
            })
        });

        const data = await response.json();
        if (data.code === 1) {
            showToast('验证码已发送');
            startCountdown();
        } else {
            showToast(data.msg || '发送失败');
        }
    } catch (error) {
        console.error('发送验证码错误:', error);
        showToast('网络错误，请重试');
    }
}

function startCountdown() {
    smsCountdown = 60;
    const btn = document.getElementById('btnSendSms');

    const timer = setInterval(() => {
        smsCountdown--;
        btn.textContent = `${smsCountdown}秒后重试`;

        if (smsCountdown <= 0) {
            clearInterval(timer);
            btn.textContent = '获取验证码';
        }
    }, 1000);
}

// showToast函数已移到ios-toast.js，使用iOS风格弹窗

function wechatLogin() {
    try {
        const rtn = encodeURIComponent(location.origin + '/providence/index.html');
        // 统一后端发起入口，自动判断是否在微信内
        const API_BASE = window.API_CONFIG?.baseURL || 'https://api.frevix.top';
        location.href = API_BASE + '/auth/wechat/start?return=' + rtn;
    } catch (e) {
        console.error(e);
    }
}
