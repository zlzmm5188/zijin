// Providence 项目详情页 - 完全重构版
// 目标：简单直接，确保数据能正常显示

console.log('📜 项目详情脚本加载');

// 获取URL参数
function getUrlParam(name) {
    const urlParams = new URLSearchParams(window.location.search);
    return urlParams.get(name);
}

// 等待API加载
function waitForAPI() {
    return new Promise((resolve) => {
        if (window.API_CONFIG) {
            resolve();
        } else {
            const check = setInterval(() => {
                if (window.API_CONFIG) {
                    clearInterval(check);
                    resolve();
                }
            }, 50);
            setTimeout(() => { clearInterval(check); resolve(); }, 3000);
        }
    });
}

// 初始化
async function init() {
    console.log('🚀 项目详情页初始化');
    
    const projectId = getUrlParam('id');
    if (!projectId) {
        alert('缺少项目ID参数');
        return;
    }
    
    console.log('📋 项目ID:', projectId);
    await waitForAPI();
    await loadProject(projectId);
}

// 加载项目数据
async function loadProject(id) {
    try {
        const API_BASE = window.API_CONFIG?.baseURL || 'https://api.frevix.top';
        const url = `${API_BASE}/fund/project/detail?id=${id}`;
        
        console.log('📡 请求:', url);
        
        const res = await fetch(url);
        const data = await res.json();
        
        console.log('📦 响应:', data);
        
        if ((data.code === 1 || data.code === 200) && data.data) {
            const project = data.data;
            console.log('✅ 项目数据:', project);
            
            // 更新页面显示
            updatePage(project);
        } else {
            console.error('❌ API错误:', data.message);
            showError(data.message || '加载失败');
        }
    } catch (err) {
        console.error('❌ 加载失败:', err);
        showError('网络错误');
    }
}

// 更新页面显示
function updatePage(p) {
    console.log('🎨 更新页面');
    
    // 标题
    const title = document.querySelector('h1, h2, .project-title');
    if (title) title.textContent = p.title || '项目详情';
    
    // 四个关键指标
    const cycle = document.getElementById('cycle');
    if (cycle) cycle.textContent = (p.cycle_days || 0) + '天';
    
    const rateVip = document.getElementById('rateVip');
    if (rateVip) rateVip.textContent = (p.vip_rate || 0) + '%';
    
    const maxAmt = document.getElementById('maxAmt');
    if (maxAmt) maxAmt.textContent = (p.max_invest || 0);
    
    const minAmt = document.getElementById('minAmt');
    if (minAmt) minAmt.textContent = (p.min_invest || 0);
    
    // 募集进度（如果有元素）
    const schedule = document.querySelector('.schedule, #schedule');
    if (schedule) schedule.textContent = (p.schedule || 0) + '%';
    
    const remain = document.querySelector('.remain, #remain');
    if (remain) remain.textContent = (p.remain || 0);
    
    // 隐藏所有加载中...文本
    hideAllLoading();
    
    console.log('✅ 页面更新完成');
}

// 隐藏所有加载中
function hideAllLoading() {
    const loadingEls = document.querySelectorAll('.loading, [data-loading]');
    loadingEls.forEach(el => el.style.display = 'none');
    
    // 移除加载中...文本
    document.body.innerHTML = document.body.innerHTML.replace(/加载中\.\.\./g, '');
    document.body.innerHTML = document.body.innerHTML.replace(/正在加载项目信息/g, '');
    document.body.innerHTML = document.body.innerHTML.replace(/正在加载/g, '');
}

// 显示错误
function showError(msg) {
    const h2 = document.querySelector('h2');
    if (h2) h2.textContent = '加载失败: ' + msg;
    alert(msg);
}

// 页面加载完成
document.addEventListener('DOMContentLoaded', init);
